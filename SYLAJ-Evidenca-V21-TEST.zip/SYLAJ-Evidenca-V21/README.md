# SYLAJ-Evidenca V20

Aplikacion për evidencën e punës, delavcev, orodja, bagerjev, vozil, računov, goriva, izmer dhe rrobave të punës për **SYLAJ gradbeništvo d.o.o.**

Ndërtuar me HTML + JavaScript + Supabase. Gati për **GitHub Pages**.

## Nisja

1. Hapni `index.html` ose `SYLAJ-Evidenca-V20.html` në shfletues (ose vendoseni në GitHub Pages).
2. Hyni me llogarinë tuaj (admin / vodja).
3. Për PWA: shtoje në ekranin kryesor të telefonit.

## Module (V20)

| Modul | Përshkrim |
|-------|-----------|
| 🕒 Delovne ure | Auto/manual, malica, korrigjim, fshirje, Excel (dnevno / mesečno / letno / 12 muaj) |
| 👷 Delavci | Shtim, transferim midis ekipëve (Fitimi / Lumi), arkivim (deaktivim) |
| 📦 Orodja / Skladišče | Marrje, kthim, inventar, foto |
| 🏗️ Gradbišča | Punime ditore, sasi, foto, raporte |
| 🚜 Bagerji | Orë, naftë, servise, shpenzime |
| 🚐 Vozila | Km, naftë, evidenca |
| ⛽ Gorivo / Nafta | Raporte sipas ekipi / gradbiščes / bagërit / automjetit |
| 🧾 Računi | Hyrëse/dalëse, OCR, QR, DDV, foto |
| 📐 Izmere | Kamera, GPS, galeria, matje m / m² / m³ + obračun |
| 📍 GPS | Lokacione |
| ⭐ Ocene | Vlerësime delavcev |
| 📋 Zgodovina / Popravi | Audit & korrigjime (admin) |
| 👕 **Rrobat e punës** (e re në V20) | Evidenca e shpërndarjes së rrobave |

## Excel raporte (V20)

Butoni **Prenesi Excel (.xlsx)** krijon fletë:
- **Navodila**
- **Dnevno**
- **Mesečno**
- **Letno**
- **Letni pregled** (12 muaj sipas delavcit)
- **Ekipe letno** (12 muaj sipas ekipit)

Delavcit me të njëjtin emër **nuk bashkohen**. Malica **nuk zbritet** nga orët.

## Kalimi i vitit

Zgjedhësi i vitit mbështet deri në 2100. Të dhënat e viteve të mëparshme mbeten në databazë. Nuk ka nevojë për migrim manual për 2027.

## Tabela e re për Rrobat (opsionale)

Nëse dëshironi të përdorni modulin e rrobave, krijoni në Supabase (SQL Editor):

```sql
create table if not exists public.rrobat_evidenca (
  id uuid primary key default gen_random_uuid(),
  delavec_id uuid references public.delavci(id),
  data date not null,
  lloji text,
  sasia numeric default 1,
  madhesia text,
  opomba text,
  foto_url text,
  created_at timestamptz default now()
);

-- RLS shembull (përshtateni sipas nevojës)
alter table public.rrobat_evidenca enable row level security;
create policy "auth users can manage rrobat"
  on public.rrobat_evidenca for all
  using (auth.role() = 'authenticated')
  with check (auth.role() = 'authenticated');
```

**Mos e ndryshoni databazën live pa kopje rezervë dhe miratim.**

## Skedarët

- `SYLAJ-Evidenca-V20.html` – aplikacioni kryesor
- `index.html` – ridrejtim
- `manifest.webmanifest` – PWA
- `sylaj-*.js` – module ndihmëse (GPS, walk-scan, matje, pamja)
- Ikonat dhe logo

## Testimi i bërë / i mbetur

**Kontrolluar në kod:**
- Struktura e moduleve dhe navigimi (dashboard)
- Excel export (fletët V20)
- Versionimi, manifest, index
- Shtimi i modulit Rrobat
- Lidhjet e skripteve lokale

**Nuk është testuar me databazë reale / telefon:**
- Login & RLS
- Ruajtja e fotove në Storage
- OCR / QR real
- Kamera & GPS në pajisje
- Fshirja/korrigjimi i të dhënave të kaluara
- Offline / PWA instalim

**Këshillë:** Testoni gjithmonë me llogari testuese dhe kopje rezervë para se ta vendosni në prodhim.

## Autori / Kompania

SYLAJ gradbeništvo d.o.o.  
Versioni: **V20** (21.11.2026)
